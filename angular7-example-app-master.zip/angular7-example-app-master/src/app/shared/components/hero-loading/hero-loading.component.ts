import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-hero-loading',
  templateUrl: './hero-loading.component.html',
  styleUrls: ['./hero-loading.component.scss']
})
export class HeroLoadingComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
