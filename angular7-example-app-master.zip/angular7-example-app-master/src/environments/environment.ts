export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyC4RNNlqXSwTM1Kt6Pbgutq2yuavSQ9WnU',
    authDomain: 'ismaestro-angularexampleapp.firebaseapp.com',
    databaseURL: 'https://ismaestro-angularexampleapp.firebaseio.com',
    projectId: 'ismaestro-angularexampleapp',
    storageBucket: 'ismaestro-angularexampleapp.appspot.com',
    messagingSenderId: '965114235515'
  }
};
